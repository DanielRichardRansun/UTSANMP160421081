<?php
// Mengatur laporan kesalahan PHP untuk hanya melaporkan kesalahan fatal dan kesalahan analisis sintaksis.
error_reporting(E_ERROR | E_PARSE);

// Membuat koneksi ke database MySQL
$c = new mysqli("localhost", "root", "", "utsanmp");

// Memeriksa apakah ada data yang dikirim melalui metode POST dengan kunci 'userid'
if (isset($_POST['userid'])) {
    // Mengambil nilai 'userid' dari data yang dikirim melalui POST
    $userId = $_POST['userid'];

    // Membuat pernyataan SQL untuk mengambil data pengguna berdasarkan ID
    $sql = "SELECT * FROM user WHERE id = '$userId' ";

    // Menjalankan pernyataan SQL menggunakan objek koneksi database
    $result = $c->query($sql);

    // Mengambil objek hasil dari kueri
    $obj = $result->fetch_object();

    // Memeriksa apakah objek hasil tidak kosong (data pengguna ditemukan)
    if (!empty($obj)) {
        // Jika ditemukan, membuat array dengan hasil 'OK' dan data pengguna
        $arrayjson = array(
            'result' => 'OK',
            'data' => $obj
        );
    } else {
        // Jika tidak ditemukan, membuat array dengan hasil 'ERROR' dan pesan 'User tidak ada'
        $arrayjson = array(
            'result' => 'ERROR',
            'msg' => 'User tidak ada'
        );
    }

    // Mengonversi array hasil ke format JSON dan mencetaknya sebagai respons
    echo json_encode($arrayjson);

    // Menghentikan eksekusi skrip PHP setelah menghasilkan respons JSON
    die();
}
?>
