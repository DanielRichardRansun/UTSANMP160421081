<?php
error_reporting(E_ERROR | E_PARSE);

// Membuat koneksi ke database MySQL
$c = new mysqli("localhost", "root", "", "utsanmp");

// Memeriksa apakah ada data yang dikirim melalui metode POST dengan kunci 'username'
if(isset($_POST['username']))
{
    // Mengambil nilai dari data yang dikirim melalui POST
    $username = $_POST['username'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $pass = $_POST['pass'];
    $email = $_POST['email'];

    // Membuat pernyataan SQL untuk menyisipkan data pengguna baru ke dalam tabel 'user'
    $sql = "INSERT INTO user (email, password, username, firstname, lastname) VALUES ('$email', '$pass', '$username', '$firstname', '$lastname')";

    // Menjalankan pernyataan SQL menggunakan objek koneksi database
    $result = $c->query($sql);

    // Memeriksa hasil operasi penyisipan data
    if ($result) {
        // Jika berhasil, membuat array dengan hasil 'OK'
        $arrayjson = array(
            'result' => 'OK'
        );
    } else {
        // Jika gagal, membuat array dengan hasil 'ERROR' dan pesan kesalahan yang sesuai
        $arrayjson = array(
            'result' => 'ERROR',
            'msg' => 'Gagal memasukan data'
        );
    }

    // Mengonversi array hasil ke format JSON dan mencetaknya sebagai respons
    echo json_encode($arrayjson);

    // Menghentikan eksekusi skrip PHP setelah menghasilkan respons JSON
    die();
}
?>
