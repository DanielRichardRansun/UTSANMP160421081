<?php
// Atur laporan error
error_reporting(E_ERROR | E_PARSE);

// Koneksi ke database
$c = new mysqli("localhost", "root", "", "utsanmp");

// Periksa apakah permintaan POST berisi data yang diperlukan
if (isset($_POST['password']) && isset($_POST['userid'])) {
    // Ambil data dari permintaan POST
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $userid = $_POST['userid'];
    $pass = $_POST['password'];
    
    // Lakukan peng-updatean ke database
    $sql = "UPDATE user SET password = '$pass', lastname ='$lastname', firstname = '$firstname' WHERE id = $userid";

    // Jalankan kueri SQL
    $result = $c->query($sql);

    // Periksa apakah kueri berhasil dieksekusi
    if ($result === false || $c->affected_rows === 0) {
        // Jika gagal, kirim pesan error
        $arrayerror = array(
            'result' => 'ERROR',
            'msg' => 'Gagal Update'
        );
        echo json_encode($arrayerror);
        die();
    }

    // Jika berhasil, kirim respons OK
    $arrayjson = array(
        'result' => 'OK'
    );
    echo json_encode($arrayjson);
    die();
} else {
    // Jika data yang diperlukan tidak ditemukan dalam permintaan POST, kirim pesan error
    $arrayerror = array(
        'result' => 'ERROR',
        'msg' => 'Data tidak lengkap'
    );
    echo json_encode($arrayerror);
    die();
}
?>
