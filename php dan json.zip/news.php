<?php

$list_berita_detail = [
    [
    "id"=> "1",
    "title" =>"Cara Merawat Kucing yang baik dan benar",
    "imageURL"=> "https://static.promediateknologi.id/crop/0x0:0x0/750x500/webp/photo/p2/01/2023/11/17/Kucing-Ragamuffin-4227232859.jpg",
    "date" => "2024-01-20",
    "description" =>"Pelajari rahasia perawatan bulu yang membuat kucing Anda tampak cantik dan sehat.",
    "content"=> [
      "Tips perawatan bulu harian untuk kucing dengan berbagai jenis bulu.",
      "Produk perawatan bulu terbaik yang direkomendasikan oleh ahli hewan peliharaan.",
      "Panduan untuk menyikat, mencuci, dan merawat bulu kucing dengan benar."
    ],
    "author_name"=> "Richard"
],
[
    "id"=> "2",
    "title"=> "Jenis-Jenis anjing lucu",
    "imageURL"=> "https://asset.kompas.com/crops/UwMIwV_6QogHH56cV52eVQ8vNjU=/0x37:800x437/1200x800/data/photo/2017/05/30/2862835038.jpg",
    "date"=> "2023-10-09",
    "description"=> "Temukan jenis anjing yang cocok dengan gaya hidup dan kebutuhan keluarga Anda.",
    "content"=> [
      "Profil berbagai jenis anjing yang ramah dan cocok untuk keluarga.",
      "Pertimbangan penting sebelum mengadopsi atau membeli anjing.",
      "Tips untuk memperkenalkan anjing baru ke dalam lingkungan keluarga Anda."
    ],
    "author_name"=> "Ansa"
],
  [
    "id"=> "3",
    "title"=> "Makanan sehat untuk kucing",
    "imageURL"=> "https://res.cloudinary.com/dk0z4ums3/image/upload/v1661753020/attached_image/inilah-cara-merawat-anak-kucing-yang-tepat.jpg",
    "date"=> "2020-04-08",
    "description"=> "Resep Makanan Sehat untuk Kucing yang Disukai oleh Semua Kucing.",
    "content"=> [
      "Resep makanan kucing yang mengandung nutrisi penting untuk kesehatan dan kesejahteraan mereka.",
      "Bahan-bahan alami yang aman dan bergizi untuk dimasukkan dalam makanan kucing.",
      "Cara menyajikan dan menyimpan makanan kucing yang baik dan higienis."
    ],
    "author_name"=> "Jhonathan"
],
  [
    "id"=> "4",
    "title"=> "Mukbang YUKKK",
    "imageURL"=> "https://img.okezone.com/content/2019/11/10/298/2127978/mukbang-kepiting-raksasa-4-kg-cara-makan-vlogger-ini-bikin-ngiler-05t8mtgf1K.jpg",
    "date"=> "2021-02-17",
    "description"=> "Tren Mukbang Terbaru: Sensasi Kuliner di Dunia Virtual",
    "content"=> [
      "Pengantar tentang apa itu mukbang dan bagaimana fenomena ini berkembang.",
      "Daftar mukbanger terkenal yang memiliki jutaan pengikut di platform media sosial.",
      "Analisis tentang dampak mukbang terhadap budaya makan dan kesehatan mental."
    ],
    "author_name"=> "Udin"
],
  [
    "id"=> "5",
    "title"=> "Rawat mobilmu!",
    "imageURL"=> "https://cdn.antaranews.com/cache/1200x800/2021/02/22/4_Image_2021-02-22_at_17.43.28.v1.jpg",
    "date"=> "2024-04-06",
    "description"=> "Panduan Perawatan Otomotif Mingguan untuk Pemilik Mobil",
    "content"=> [
      "Checklist perawatan mingguan untuk menjaga mesin, kaki-kaki, dan bodi mobil.",
      "Tips membersihkan dan melindungi interior mobil dari kerusakan dan kekotoran.",
      "Panduan untuk memilih produk perawatan otomotif yang tepat untuk mobil Anda."
    ],
    "author_name"=> "Andrew"
],

    ];
    if (isset($_GET['id'])){
      // Jika parameter 'id' disertakan dalam permintaan GET
      $selectedId = $_GET['id'];
      $berita_detail = null;
      // Mencari berita dengan id yang sesuai dalam $list_berita_detail
      for($i=0; $i < count($list_berita_detail); $i++) {
          if($list_berita_detail[$i]['id'] == $selectedId){
              $berita_detail = $list_berita_detail[$i];
              break;
          }
      }
      // Mengirim berita detail yang ditemukan sebagai respons JSON
      echo json_encode($berita_detail);
  } else {
      // Jika parameter 'id' tidak disertakan dalam permintaan GET
  
      // Mengurutkan array $list_berita_detail berdasarkan tanggal
      usort($list_berita_detail, function ($a, $b) {
          return strtotime($b['date']) - strtotime($a['date']);
      });
  
      // Mengirim seluruh daftar berita yang telah diurutkan sebagai respons JSON
      echo json_encode($list_berita_detail);
  }
  