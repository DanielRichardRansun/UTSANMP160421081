<?php
error_reporting(E_ERROR | E_PARSE);

// Membuat koneksi ke database MySQL
$c = new mysqli("localhost", "root", "", "utsanmp");

// Memeriksa apakah data 'pass' dan 'username' dikirim melalui metode POST
if (isset($_POST['pass']) && isset($_POST['username'])) {
    // Mengambil nilai 'pass' dan 'username' dari data yang dikirim melalui POST
    $pass = $_POST['pass'];
    $username = $_POST['username'];

    // Membuat pernyataan SQL untuk mengambil data pengguna berdasarkan nama pengguna (username) dan kata sandi (password)
    $sql = "SELECT * FROM user WHERE username = '$username' AND password = '$pass'";

    // Menjalankan pernyataan SQL menggunakan objek koneksi database
    $result = $c->query($sql);

    // Memeriksa apakah hasil kueri menghasilkan setidaknya satu baris data
    if ($result->num_rows > 0) {
        // Jika ditemukan, mengambil objek hasil dari kueri
        $obj = $result->fetch_object();

        // Membuat array dengan hasil 'OK' dan data pengguna yang ditemukan
        $arrayjson = array(
            'result' => 'OK',
            'data' => $obj
        );
    } else {
        // Jika tidak ditemukan, membuat array dengan hasil 'ERROR' dan pesan 'User Tidak ada'
        $arrayjson = array(
            'result' => 'ERROR',
            'msg' => 'User Tidak ada'
        );
    }

    // Mengonversi array hasil ke format JSON dan mencetaknya sebagai respons
    echo json_encode($arrayjson);

    // Menghentikan eksekusi skrip PHP setelah menghasilkan respons JSON
    die();
}
?>